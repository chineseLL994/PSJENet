
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import copy
import random
import itertools


class GMD:
    def __init__(self, optimizer, reduction='mean', writer=None):
        self._optim, self._reduction = optimizer, reduction
        self.iter = 0
        self.writer = writer

    @property
    def optimizer(self):
        return self._optim

    def zero_grad(self):
        return self._optim.zero_grad(set_to_none=True)

    def step(self):
        return self._optim.step()

    def pc_backward(self, objectives, ddp_model=None):
        # 获取所有需要训练的参数（按顺序）
        all_params = []
        for group in self._optim.param_groups:
            for p in group['params']:
                if p.requires_grad:
                    all_params.append(p)
        num_params = len(all_params)
        device = all_params[0].device

        # 为每个目标存储每个参数的梯度（形状保持不变）
        per_objective_grads = []  # list of list, 每个元素是 [grad1, grad2, ...] 对应每个参数
        for i, obj in enumerate(objectives):
            self._optim.zero_grad(set_to_none=True)
            retain = (i < len(objectives) - 1)
            obj.backward(retain_graph=retain)
            # 收集梯度
            grads = []
            for p in all_params:
                if p.grad is None:
                    grads.append(torch.zeros_like(p))
                else:
                    grads.append(p.grad.clone())
            per_objective_grads.append(grads)

        # 对每个参数，在多个目标之间进行冲突投影
        # 最终每个参数的梯度为冲突投影后的结果
        final_grads = [None] * num_params

        # 对每个参数独立处理
        for param_idx in range(num_params):
            # 收集该参数在所有目标中的梯度
            param_grads = [grads[param_idx] for grads in per_objective_grads]
            # 对该参数的所有梯度进行投影冲突求解
            merged_grad = self._project_conflicting_per_param(param_grads)
            final_grads[param_idx] = merged_grad

        # 将梯度赋回参数
        for p, g in zip(all_params, final_grads):
            p.grad = g
        return

    def _project_conflicting_per_param(self, grads):
        """
        对单个参数的多个梯度进行 PCGrad 冲突投影。
        grads: list of Tensor，每个形状相同
        返回投影后的梯度 Tensor
        """
        num_task = len(grads)
        if num_task == 0:
            return torch.zeros_like(grads[0])
        # 复制梯度，防止修改原始
        grads_copy = [g.clone() for g in grads]
        # 为每个梯度计算方向投影
        for i in range(num_task):
            # 随机顺序（可选）
            indices = list(range(num_task))
            random.shuffle(indices)
            for j in indices:
                if i == j:
                    continue
                g_i = grads_copy[i]
                g_j = grads_copy[j]
                dot = torch.dot(g_i.view(-1), g_j.view(-1))
                if dot < 0:
                    # 投影到正交方向
                    proj = (dot / (g_j.norm() ** 2 + 1e-8)) * g_j
                    grads_copy[i] = g_i - proj
        # 合并：求和或平均
        if self._reduction == 'mean':
            merged = torch.stack(grads_copy).mean(dim=0)
        elif self._reduction == 'sum':
            merged = torch.stack(grads_copy).sum(dim=0)
        else:
            raise ValueError('invalid reduction method')
        return merged

    # 以下方法保留但不再使用（可删除或注释，但为了兼容性保留）
    def _project_conflicting(self, grads, has_grads, shapes=None):
        pass

    def _set_grad(self, grads):
        pass

    def _pack_grad(self, objectives, ddp):
        pass

    def _collect_module_grad(self, param_list):
        pass

    def _unflatten_grad(self, grads, shapes):
        pass