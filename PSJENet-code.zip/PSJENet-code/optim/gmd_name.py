import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import copy
import random


class GMD:
    def __init__(self, optimizer, reduction='mean', writer=None):
        self._optim, self._reduction = optimizer, reduction
        self.iter = 0
        self.writer = writer

    @property
    def optimizer(self):
        return self._optim

    def zero_grad(self):
        return self._optim.zero_grad(set_to_none=True)

    def step(self):
        return self._optim.step()

    def pc_backward(self, objectives, ddp_model=None):
        '''
        Standard, Robust PCGrad Implementation
        Works for any architecture without hard-coded parameter names.
        '''
        task_grads = []
        has_grads = []
        shapes = None

        # 1. 遍历每个任务的 loss，收集整个网络的一维梯度向量
        for obj in objectives:
            self._optim.zero_grad(set_to_none=True)
            obj.backward(retain_graph=True)

            grad_info = self._retrieve_grad()

            # 记录网络的真实参数shape（只需要记录一次）
            if shapes is None:
                shapes = [g['shape'] for g in grad_info]

            # 把当前任务的所有参数梯度展平为一维长向量
            flat_grad = torch.cat([g['grad'].flatten() for g in grad_info])
            has_grad_mask = torch.cat([g['has_grad'].flatten() for g in grad_info])

            task_grads.append(flat_grad)
            has_grads.append(has_grad_mask)

        # 2. 对冲突的一维梯度进行投影消除
        pc_grad_flat = self._project_conflicting(task_grads, has_grads)

        # 3. 把一维向量还原回网络原本的 Shape 并赋值
        pc_grad_unflattened = self._unflatten_grad(pc_grad_flat, shapes)
        self._set_grad(pc_grad_unflattened)

    def _project_conflicting(self, grads, has_grads):
        # 找出所有任务都有梯度的参数位置
        shared = torch.stack(has_grads).prod(0).bool()
        pc_grad, num_task = copy.deepcopy(grads), len(grads)

        for i in range(num_task):
            task_order = list(range(num_task))
            random.shuffle(task_order)

            for j in task_order:
                if i == j:
                    continue
                g_i = pc_grad[i]
                g_j = grads[j]  # 参考原始梯度进行投影

                g_i_g_j = torch.dot(g_i, g_j)
                if g_i_g_j < 0:
                    # 增加 1e-8 防止除以 0
                    coef = g_i_g_j / (g_j.norm() ** 2 + 1e-8)
                    pc_grad[i] -= coef * g_j

        merged_grad = torch.zeros_like(grads[0])
        self.iter += 1

        if self._reduction == 'mean':
            merged_grad[shared] = torch.stack([g[shared] for g in pc_grad]).mean(dim=0)
        elif self._reduction == 'sum':
            merged_grad[shared] = torch.stack([g[shared] for g in pc_grad]).sum(dim=0)
        else:
            raise ValueError('invalid reduction method')

        merged_grad[~shared] = torch.stack([g[~shared] for g in pc_grad]).sum(dim=0)
        return merged_grad

    def _set_grad(self, grads):
        '''
        Strictly assign gradients back based on optimizer's native parameter order
        '''
        idx = 0
        for group in self._optim.param_groups:
            for p in group['params']:
                # 直接赋值，PyTorch 会安全接收
                p.grad = grads[idx]
                idx += 1
        return

    def _unflatten_grad(self, flat_grad, shapes):
        unflatten_grad = []
        idx = 0
        for shape in shapes:
            # 计算参数元素个数，确保返回 Python int
            length = int(np.prod(shape))
            # 跳过没有元素的参数（理论上不会发生，但为了安全）
            if length == 0:
                unflatten_grad.append(None)
                continue
            # 切片时 idx 和 length 都应为 Python int
            unflatten_grad.append(flat_grad[idx:idx + length].view(shape).clone())
            idx += length
        return unflatten_grad

    def _retrieve_grad(self):
        param_info_list = []
        for group in self._optim.param_groups:
            # 注意：optimizer 的 param_groups 可能没有 'name' 键，这里我们只关心参数本身
            for p in group['params']:
                if p.grad is None:
                    param_info = {
                        'grad': torch.zeros_like(p).to(p.device),
                        'shape': p.shape,
                        'has_grad': torch.zeros_like(p).to(p.device)
                    }
                else:
                    param_info = {
                        'grad': p.grad.clone(),
                        'shape': p.grad.shape,
                        'has_grad': torch.ones_like(p).to(p.device)
                    }
                param_info_list.append(param_info)
        return param_info_list