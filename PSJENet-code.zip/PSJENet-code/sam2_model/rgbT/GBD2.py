import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class SpatialAttention(nn.Module):
    def __init__(self):
        super().__init__()
        self.spatial_attn = nn.Sequential(
            nn.Conv2d(2, 1, 3, padding=1, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        combined = torch.cat([avg_out, max_out], dim=1)
        attn = self.spatial_attn(combined)
        return attn
class MultiScaleSpatialAttention(nn.Module):
    def __init__(self, in_channels, kernels=[1, 3, 5]):
        super().__init__()
        self.branches = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(in_channels, in_channels, k, padding=k//2, bias=False),
                SpatialAttention()
            ) for k in kernels
        ])

    def forward(self, x):
        branch_outs = [branch(x) for branch in self.branches]
        summed_attn = torch.stack(branch_outs).sum(dim=0)
        return summed_attn


class GranularBall(nn.Module):
    def __init__(self, in_ch, num_balls=32, proj_dim=None, use_residual=True, use_diag_cov=True, tau=1.0):
        super().__init__()
        self.in_ch = in_ch
        self.proj_dim = proj_dim or in_ch
        self.num_balls = num_balls
        self.use_residual = use_residual
        self.use_diag_cov = use_diag_cov
        self.tau = tau

        self.centers = nn.Parameter(torch.randn(num_balls, self.proj_dim) * 0.01)
        # ★ 新增：半径/对角协方差（softplus 保正）
        if use_diag_cov:
            self.log_sigma = nn.Parameter(torch.zeros(num_balls, self.proj_dim))  # diag std
        else:
            self.log_radius = nn.Parameter(torch.zeros(num_balls, 1))            # scalar std

        if self.proj_dim != in_ch:
            self.proj_in  = nn.Conv2d(in_ch, self.proj_dim, 1, bias=True)
            self.bn_in    = nn.BatchNorm2d(self.proj_dim)
            self.proj_out = nn.Conv2d(self.proj_dim, in_ch, 1, bias=False)
            self.bn_out   = nn.BatchNorm2d(in_ch)
        else:
            self.proj_in = self.proj_out = None

        self.refine = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(in_ch),
            nn.ReLU(inplace=True)
        )

    def forward(self, x, tau=1.0):
        B, C, H, W = x.shape
        z = self.bn_in(self.proj_in(x)) if self.proj_in is not None else x
        d = z.shape[1]
        z_flat = z.view(B, d, H*W).permute(0,2,1)          # (B,N,d)

        # ★ 计算“球”距离（缩放欧氏/对角马氏）
        dif = z_flat.unsqueeze(2) - self.centers.unsqueeze(0).unsqueeze(0)  # (B,N,K,d)
        if self.use_diag_cov:
            sigma = F.softplus(self.log_sigma).unsqueeze(0).unsqueeze(0)    # (1,1,K,d)
        else:
            sigma = F.softplus(self.log_radius).unsqueeze(0).unsqueeze(0)   # (1,1,K,1)
        dif_scaled = dif / sigma                                           # 广播
        dist2 = (dif_scaled ** 2).sum(-1)                                  # (B,N,K)

        att = F.softmax(-dist2 / max(1e-6, tau), dim=-1)                   # 软集合归属

        recon_flat = torch.matmul(att, self.centers)                        # (B,N,d)
        recon = recon_flat.permute(0,2,1).view(B, d, H, W)

        if self.proj_out is not None:
            recon = self.bn_out(self.proj_out(recon))

        out = recon + x if self.use_residual else recon
        return self.refine(out), att, sigma, dif

class GranularBallSegDecoder(nn.Module):
    """
    专为 SAM_ACI 设计的分割解码器，接收四个尺度的特征（从高分辨率到低分辨率），
    内部使用可学习的 GranularBall 模块（在最小分辨率上）进行特征增强，
    然后经多尺度上采样融合，输出单通道分割 logits。
    """
    def __init__(self, in_channels_list=[144, 288, 576, 1152], out_channels=256,
                 num_balls=32, tau=1.0, use_residual=True, use_diag_cov=True):
        super().__init__()
        c1, c2, c3, c4 = in_channels_list

        # ★ 替换为可学习的 GranularBall 模块（作用于最低分辨率 c4）
        self.granular_enhance4 = GranularBall(
            in_ch=c4,
            num_balls=num_balls,
            proj_dim=None,          # 保持通道数不变
            use_residual=use_residual,
            use_diag_cov=use_diag_cov,
            tau=tau
        )
        self.granular_enhance3 = GranularBall(
            in_ch=c3,
            num_balls=num_balls,
            proj_dim=None,  # 保持通道数不变
            use_residual=use_residual,
            use_diag_cov=use_diag_cov,
            tau=tau
        )
        self.granular_enhance2 = GranularBall(
            in_ch=c2,
            num_balls=num_balls,
            proj_dim=None,  # 保持通道数不变
            use_residual=use_residual,
            use_diag_cov=use_diag_cov,
            tau=tau
        )
        self.granular_enhance1 = GranularBall(
            in_ch=c1,
            num_balls=num_balls,
            proj_dim=None,  # 保持通道数不变
            use_residual=use_residual,
            use_diag_cov=use_diag_cov,
            tau=tau
        )

        # 通道统一投影
        self.proj_c1 = nn.Sequential(
            nn.Conv2d(c1, out_channels, 1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        self.proj_c2 = nn.Sequential(
            nn.Conv2d(c2, out_channels, 1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        self.proj_c3 = nn.Sequential(
            nn.Conv2d(c3, out_channels, 1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        self.proj_c4 = nn.Sequential(
            nn.Conv2d(c4, out_channels, 1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

        # 多尺度空间注意力（保持不变）
        self.sa_c1 = MultiScaleSpatialAttention(out_channels, kernels=[1,3,5])
        self.sa_c2 = MultiScaleSpatialAttention(out_channels, kernels=[1,3,5])
        self.sa_c3 = MultiScaleSpatialAttention(out_channels, kernels=[1,3,5])
        self.sa_c4 = MultiScaleSpatialAttention(out_channels, kernels=[1,3,5])

        # 上采样路径（保持不变）
        self.up4 = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        )
        self.up3 = nn.Sequential(
            nn.Conv2d(out_channels*2, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        )
        self.up2 = nn.Sequential(
            nn.Conv2d(out_channels*2, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        )
        self.up1 = nn.Sequential(
            nn.Conv2d(out_channels*2, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

        # 最终预测：输出单通道分割 logits
        self.pred = nn.Sequential(
            nn.Dropout2d(0.1),
            nn.Conv2d(out_channels, 1, kernel_size=1)
        )

    def forward(self, multi_scale_feats):
        """
        multi_scale_feats: list of 4 tensors [c1, c2, c3, c4]
                          c1: 高分辨率 (B,144,H1,W1)
                          c4: 低分辨率 (B,1152,H4,W4)
        """
        c1, c2, c3, c4 = multi_scale_feats

        # ★ 使用可学习的 GranularBall 模块进行特征增强（取第一个输出）
        c4_enhanced, _, _, _ = self.granular_enhance4(c4)
        c3_enhanced, _, _, _ = self.granular_enhance3(c3)
        c2_enhanced, _, _, _ = self.granular_enhance2(c2)
        c1_enhanced, _, _, _ = self.granular_enhance1(c1)

        # 通道统一
        c1 = self.proj_c1(c1_enhanced)
        c2 = self.proj_c2(c2_enhanced)
        c3 = self.proj_c3(c3_enhanced)
        c4 = self.proj_c4(c4_enhanced)

        # 空间注意力
        c1 = c1 * self.sa_c1(c1)
        c2 = c2 * self.sa_c2(c2)
        c3 = c3 * self.sa_c3(c3)
        c4 = c4 * self.sa_c4(c4)

        # 自顶向下融合
        x = self.up4(c4)
        if x.shape[2:] != c3.shape[2:]:
            x = F.interpolate(x, size=c3.shape[2:], mode='bilinear', align_corners=True)
        x = torch.cat([x, c3], dim=1)
        x = self.up3(x)

        if x.shape[2:] != c2.shape[2:]:
            x = F.interpolate(x, size=c2.shape[2:], mode='bilinear', align_corners=True)
        x = torch.cat([x, c2], dim=1)
        x = self.up2(x)

        if x.shape[2:] != c1.shape[2:]:
            x = F.interpolate(x, size=c1.shape[2:], mode='bilinear', align_corners=True)
        x = torch.cat([x, c1], dim=1)
        x = self.up1(x)

        out = self.pred(x)  # (B,1,H1,W1)
        return out