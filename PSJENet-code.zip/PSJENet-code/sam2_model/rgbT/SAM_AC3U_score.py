import numbers
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, repeat
from sam2.build_sam import build_sam2
from sam2.modeling.backbones.hieradet import do_pool, window_partition, window_unpartition
from sam2_model.MoE.Moase_moe_sep import Moe_Adapter
from sam2_model.rgbT.Extra_stage import FifthBlock
from sam2_model.rgbT.GBD2 import GranularBallSegDecoder


def conv3x3(in_planes, out_planes, stride=1, has_bias=False):
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride, padding=1, bias=has_bias)

def conv3x3_bn_relu(in_planes, out_planes, stride=1):
    return nn.Sequential(
        conv3x3(in_planes, out_planes, stride),
        nn.BatchNorm2d(out_planes),
        nn.ReLU(inplace=True),
    )

class Conv1x1(nn.Module):
    def __init__(self, in_channel, out_channel, relu=True):
        super(Conv1x1, self).__init__()
        conv = [
            nn.Conv2d(in_channel, out_channel, 1, bias=False),
            nn.BatchNorm2d(out_channel)
        ]
        if relu:
            conv.append(nn.ReLU(inplace=True))
        self.conv = nn.Sequential(*conv)
    def forward(self, x):
        return self.conv(x)

class DWConv2(nn.Module):
    def __init__(self, in_channel, k=3, d=1, relu=False):
        super(DWConv2, self).__init__()
        conv = [
            nn.Conv2d(in_channel, in_channel, k, 1, (k // 2) * d, d, in_channel, False),
            nn.BatchNorm2d(in_channel)
        ]
        if relu:
            conv.append(nn.ReLU(inplace=True))
        self.conv = nn.Sequential(*conv)
    def forward(self, x):
        return self.conv(x)

class DSConv3x3(nn.Module):
    def __init__(self, in_channel, out_channel, d=1, relu_dw=False, relu_p=True):
        super(DSConv3x3, self).__init__()
        self.conv = nn.Sequential(
            DWConv2(in_channel, 3, d, relu_dw),
            Conv1x1(in_channel, out_channel, relu_p)
        )
    def forward(self, x):
        return self.conv(x)

class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc1 = nn.Conv2d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // 16, in_planes, 1, bias=False)
        self.sigmoid = nn.Sigmoid()
    def forward(self, x):
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        return self.sigmoid(max_out)

class layer(nn.Module):
    def __init__(self, in_channel, num_head):
        super(layer, self).__init__()
        self.layer = FifthBlock(dim=in_channel, num_heads=num_head)
    def forward(self, x):
        return self.layer(x)

# ==========================================
# 非对称质量约束融合模块（RGB-dominant ACQC）
# ==========================================
class DepthQualityConstraint(nn.Module):

    def __init__(self, in_channels_list=[1152, 576, 288, 144], hidden_dim=256):
        super().__init__()
        self.num_scales = len(in_channels_list)

        self.depth_refine = nn.ModuleList()
        self.gate_heads = nn.ModuleList()

        for in_ch in in_channels_list:
            mid = max(in_ch // 8, 32)
            self.depth_refine.append(
                nn.Sequential(
                    DSConv3x3(in_ch, in_ch, relu_dw=False, relu_p=True),
                    DSConv3x3(in_ch, in_ch, relu_dw=False, relu_p=True),
                )
            )
            # gate_i = sigmoid(phi([R_i, D_i, |R_i-D_i|]))
            # 这里的 gate 是 depth 的可靠性图，只作用于 depth 分支。
            self.gate_heads.append(
                nn.Sequential(
                    Conv1x1(in_ch * 3, mid, relu=True),
                    conv3x3_bn_relu(mid, mid),
                    nn.Conv2d(mid, 1, kernel_size=1, bias=True),
                    nn.Sigmoid()
                )
            )

        self.global_quality = nn.Sequential(
            nn.Linear(self.num_scales, hidden_dim // 4),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim // 4, 1),
            nn.Sigmoid()
        )

    def forward(self, depth_feats, rgb_feats):
        purified_depth_feats = []
        quality_maps = []
        quality_scalars = []

        for i, (d, r) in enumerate(zip(depth_feats, rgb_feats)):
            # 尺寸保护，避免外部改动导致尺度不一致
            if r.shape[-2:] != d.shape[-2:]:
                r = F.interpolate(r, size=d.shape[-2:], mode='bilinear', align_corners=False)

            # 质量预测：不仅看 depth 自身，也看 RGB-depth 的结构一致性
            diff = torch.abs(r - d)
            q = self.gate_heads[i](torch.cat([r, d, diff], dim=1))  # [B,1,H,W]

            # depth purification: 低质量区域直接压制 depth，防止污染 RGB 主干
            d_ref = self.depth_refine[i](d)
            d_clean = d_ref * q

            purified_depth_feats.append(d_clean)
            quality_maps.append(q)
            quality_scalars.append(q.mean(dim=[2, 3]))  # [B,1]

        # 全局质量分数，用于原来的 gate loss / SmoothL1 监督接口
        q_global = torch.cat(quality_scalars, dim=1)      # [B, num_scales]
        depth_score = self.global_quality(q_global)       # [B,1]
        return purified_depth_feats, depth_score, quality_maps


class RGBDominantQCBlock(nn.Module):
    """
    RGB-dominant asymmetric quality-constrained fusion core.

    非对称性体现在：
    1) RGB 是主状态 R，不被 depth 反向重写；
    2) depth 先经过质量图 q 抑制，得到 Dq；
    3) depth 只能以 gated residual 的形式注入 RGB：F = R + gamma * g * T(Dq)；
    4) 没有 RGB/depth 对称拼接后等权卷积，也没有 depth 分支反向主导输出。
    """
    def __init__(self, out_channel):
        super().__init__()
        mid = max(out_channel // 8, 32)

        self.rgb_ca = ChannelAttention(out_channel)
        self.depth_to_rgb = DSConv3x3(out_channel, out_channel, relu_dw=False, relu_p=True)

        # 根据 R、Dq 和二者差异进一步估计“局部可注入性”
        self.inject_gate = nn.Sequential(
            Conv1x1(out_channel * 3, mid, relu=True),
            conv3x3_bn_relu(mid, mid),
            nn.Conv2d(mid, 1, kernel_size=1, bias=True),
            nn.Sigmoid()
        )

        # 小初值，保证训练初期模型退化为 RGB-dominant，depth 不会一开始就污染主干
        self.gamma = nn.Parameter(torch.tensor(0.1, dtype=torch.float32))
        self.out_proj = DSConv3x3(out_channel, out_channel, relu_dw=False, relu_p=True)

    def forward(self, r, d, q=None):
        if d.shape[-2:] != r.shape[-2:]:
            d = F.interpolate(d, size=r.shape[-2:], mode='bilinear', align_corners=False)
        if q is None:
            q = torch.ones(d.size(0), 1, d.size(2), d.size(3), device=d.device, dtype=d.dtype)
        elif q.shape[-2:] != r.shape[-2:]:
            q = F.interpolate(q, size=r.shape[-2:], mode='bilinear', align_corners=False)

        # 只约束 depth：质量低的位置，depth 特征被直接削弱
        d_q = d * q

        # 局部注入门控：depth 与 RGB 越一致、质量越高，越允许注入
        local_gate = self.inject_gate(torch.cat([r, d_q, torch.abs(r - d_q)], dim=1))
        g = q * local_gate

        # RGB 主导表征，depth 只能作为残差补充
        r_dom = r * (1.0 + self.rgb_ca(r))
        d_res = self.depth_to_rgb(d_q)
        out = r_dom + torch.tanh(self.gamma) * g * d_res
        out = self.out_proj(out)
        return out


class ACQC_R(nn.Module):

    def __init__(self, in_channel, out_channel):
        super().__init__()
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.rgb_fuse_same = conv3x3_bn_relu(in_channel + out_channel, out_channel)
        self.rgb_fuse_up = conv3x3_bn_relu(in_channel + out_channel, out_channel)
        self.core = RGBDominantQCBlock(out_channel)

    def forward(self, r1, r2, d, q=None):
        if r1.shape == r2.shape:
            r = self.rgb_fuse_same(torch.cat([r1, r2], dim=1))
        else:
            r2 = self.upsample2(r2)
            if r2.shape[-2:] != r1.shape[-2:]:
                r2 = F.interpolate(r2, size=r1.shape[-2:], mode='bilinear', align_corners=False)
            r = self.rgb_fuse_up(torch.cat([r1, r2], dim=1))
        return self.core(r, d, q)


class ACQC_D(nn.Module):
    """
    Top-down prior type ACQC.
    用于原 CIA_D1 / CIA_D2 的位置。


    """
    def __init__(self, in_channel, out_channel):
        super().__init__()
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.rgb_prior_fuse = conv3x3_bn_relu(in_channel + out_channel, out_channel)
        self.core = RGBDominantQCBlock(out_channel)

    def forward(self, r, d, prior, q=None):
        prior = self.upsample2(prior)
        if prior.shape[-2:] != r.shape[-2:]:
            prior = F.interpolate(prior, size=r.shape[-2:], mode='bilinear', align_corners=False)
        r = self.rgb_prior_fuse(torch.cat([r, prior], dim=1))
        return self.core(r, d, q)



class QGP(DepthQualityConstraint):
    pass


# ==========================================
# 主模型 (集成 SAM2 + AC3U + GBD)
# ==========================================
class Model(nn.Module):
    def __init__(self, cfg) -> None:
        super().__init__()
        self.cfg = cfg
        self.model = build_sam2(self.cfg.sam2_cfg, self.cfg.sam2_checkpoint)
        self._bb_feat_sizes = [(128, 128), (64, 64), (32, 32)]

        self.lenth0_1, self.lenth2_7, self.lenth8_43, self.lenth44_47 = 2, 6, 36, 4
        self.rgb0_1, self.depth0_1d, self.flow0_1d = nn.ModuleList(), nn.ModuleList(), nn.ModuleList()
        self.rgb2_7, self.depth2_7d, self.flow2_7d = nn.ModuleList(), nn.ModuleList(), nn.ModuleList()
        self.rgb8_43, self.depth8_43d, self.flow8_43d = nn.ModuleList(), nn.ModuleList(), nn.ModuleList()
        self.rgb44_47, self.depth44_47d, self.flow44_47d = nn.ModuleList(), nn.ModuleList(), nn.ModuleList()

        for _ in range(self.lenth0_1):
            self.rgb0_1.append(Moe_Adapter(144, 32, 0.5))
            self.depth0_1d.append(Moe_Adapter(144, 32, 0.5))
            self.flow0_1d.append(Moe_Adapter(144, 32, 0.5))
        for _ in range(self.lenth2_7):
            self.rgb2_7.append(Moe_Adapter(288, 32, 0.5))
            self.depth2_7d.append(Moe_Adapter(288, 32, 0.5))
            self.flow2_7d.append(Moe_Adapter(288, 32, 0.5))
        for _ in range(self.lenth8_43):
            self.rgb8_43.append(Moe_Adapter(576, 32, 0.5))
            self.depth8_43d.append(Moe_Adapter(576, 32, 0.5))
            self.flow8_43d.append(Moe_Adapter(576, 32, 0.5))
        for _ in range(self.lenth44_47):
            self.rgb44_47.append(Moe_Adapter(1152, 32, 0.5))
            self.depth44_47d.append(Moe_Adapter(1152, 32, 0.5))
            self.flow44_47d.append(Moe_Adapter(1152, 32, 0.5))

        self.layer5 = layer(1152, 16)
        self.CIA_R1 = ACQC_R(in_channel=1152, out_channel=1152)
        self.CIA_R2 = ACQC_R(in_channel=1152, out_channel=576)
        self.CIA_D1 = ACQC_D(in_channel=576, out_channel=288)
        self.CIA_D2 = ACQC_D(in_channel=288, out_channel=144)


        self.decoder_fusion = GranularBallSegDecoder(
            in_channels_list=[144, 288, 576, 1152],
            out_channels=256
        )
        self.decoder_rgb = GranularBallSegDecoder(
            in_channels_list=[144, 288, 576, 1152],
            out_channels=256
        )
        self.decoder_depth = GranularBallSegDecoder(
            in_channels_list=[144, 288, 576, 1152],
            out_channels=256
        )

        self.qgp = QGP(in_channels_list=[1152, 576, 288, 144], hidden_dim=256)


    def setup(self):
        if self.cfg.freeze_image_encoder:
            for name, param in self.model.named_parameters():
                if "sam_mask_decoder" not in name and "CIA" not in name and "layer5" not in name:
                    param.requires_grad_(False)

    def forward(self, rgb, depth):
        # 双流特征提取 (Backbone + MoE)
        rgb = self.model.image_encoder.trunk.patch_embed(rgb)
        rgb = rgb + self.model.image_encoder.trunk._get_pos_embed(rgb.shape[1:3])
        depth = self.model.image_encoder.trunk.patch_embed(depth)
        depth = depth + self.model.image_encoder.trunk._get_pos_embed(depth.shape[1:3])
        # flow = self.model.image_encoder.trunk.patch_embed(flow)
        # flow = flow + self.model.image_encoder.trunk._get_pos_embed(flow.shape[1:3])

        depth_outputs = []
        rgb_outputs = []
        # flow_outputs = []

        for i, blk in enumerate(self.model.image_encoder.trunk.blocks):
            # ===== RGB 分支 =====
            rgb_shortcut = rgb
            rgb = blk.norm1(rgb)
            if blk.dim != blk.dim_out:
                rgb_shortcut = do_pool(blk.proj(rgb), blk.pool)

            window_size = blk.window_size
            if window_size > 0:
                Hb, Wb = rgb.shape[1], rgb.shape[2]
                rgb, pad_hw = window_partition(rgb, window_size)

            B, H, W, _ = rgb.shape
            qkv = blk.attn.qkv(rgb).reshape(B, H * W, 3, blk.attn.num_heads, -1)
            q, k, v = torch.unbind(qkv, 2)
            if blk.attn.q_pool:
                q = do_pool(q.reshape(B, H, W, -1), blk.attn.q_pool)
                H, W = q.shape[1:3]
                q = q.reshape(B, H * W, blk.attn.num_heads, -1)
            rgb = F.scaled_dot_product_attention(q.transpose(1, 2), k.transpose(1, 2), v.transpose(1, 2))
            rgb = rgb.transpose(1, 2).reshape(B, H, W, -1)
            rgb = blk.attn.proj(rgb)

            if blk.q_stride:
                window_size = blk.window_size // blk.q_stride[0]
                Hb, Wb = rgb_shortcut.shape[1:3]
                pad_h = (window_size - Hb % window_size) % window_size
                pad_w = (window_size - Wb % window_size) % window_size
                pad_hw = (Hb + pad_h, Wb + pad_w)
            if blk.window_size > 0:
                rgb = window_unpartition(rgb, window_size, pad_hw, (Hb, Wb))

            rgb = rgb_shortcut + blk.drop_path(rgb)

            # MoE 适配器注入 (RGB)
            if 0 <= i <= 1:
                rgb = rgb + blk.drop_path(blk.mlp(blk.norm2(rgb))) + self.rgb0_1[i](rgb)
            elif 2 <= i <= 7:
                rgb = rgb + blk.drop_path(blk.mlp(blk.norm2(rgb))) + self.rgb2_7[i - 2](rgb)
            elif 8 <= i <= 43:
                rgb = rgb + blk.drop_path(blk.mlp(blk.norm2(rgb))) + self.rgb8_43[i - 8](rgb)
            elif 44 <= i <= 47:
                rgb = rgb + blk.drop_path(blk.mlp(blk.norm2(rgb))) + self.rgb44_47[i - 44](rgb)

            # ===== Depth 分支 =====
            depth_shortcut = depth
            depth = blk.norm1(depth)
            if blk.dim != blk.dim_out:
                depth_shortcut = do_pool(blk.proj(depth), blk.pool)

            window_size = blk.window_size
            if window_size > 0:
                Hb, Wb = depth.shape[1], depth.shape[2]
                depth, pad_hw = window_partition(depth, window_size)

            B, H, W, _ = depth.shape
            qkv = blk.attn.qkv(depth).reshape(B, H * W, 3, blk.attn.num_heads, -1)
            q, k, v = torch.unbind(qkv, 2)
            if blk.attn.q_pool:
                q = do_pool(q.reshape(B, H, W, -1), blk.attn.q_pool)
                H, W = q.shape[1:3]
                q = q.reshape(B, H * W, blk.attn.num_heads, -1)
            depth = F.scaled_dot_product_attention(q.transpose(1, 2), k.transpose(1, 2), v.transpose(1, 2))
            depth = depth.transpose(1, 2).reshape(B, H, W, -1)
            depth = blk.attn.proj(depth)

            if blk.q_stride:
                window_size = blk.window_size // blk.q_stride[0]
                Hb, Wb = depth_shortcut.shape[1:3]
                pad_h = (window_size - Hb % window_size) % window_size
                pad_w = (window_size - Wb % window_size) % window_size
                pad_hw = (Hb + pad_h, Wb + pad_w)
            if blk.window_size > 0:
                depth = window_unpartition(depth, window_size, pad_hw, (Hb, Wb))

            depth = depth_shortcut + blk.drop_path(depth)

            # MoE 适配器注入 (Depth)
            if 0 <= i <= 1:
                depth = depth + blk.drop_path(blk.mlp(blk.norm2(depth))) + self.depth0_1d[i](depth)
            elif 2 <= i <= 7:
                depth = depth + blk.drop_path(blk.mlp(blk.norm2(depth))) + self.depth2_7d[i - 2](depth)
            elif 8 <= i <= 43:
                depth = depth + blk.drop_path(blk.mlp(blk.norm2(depth))) + self.depth8_43d[i - 8](depth)
            elif 44 <= i <= 47:
                depth = depth + blk.drop_path(blk.mlp(blk.norm2(depth))) + self.depth44_47d[i - 44](depth)


            if (i == self.model.image_encoder.trunk.stage_ends[-1]) or (
                    i in self.model.image_encoder.trunk.stage_ends and self.model.image_encoder.trunk.return_interm_layers
            ):
                rgb_outputs.append(rgb.permute(0, 3, 1, 2))
                depth_outputs.append(depth.permute(0, 3, 1, 2))
                # flow_outputs.append(flow.permute(0, 3, 1, 2))


        r4, r3, r2, r1 = rgb_outputs
        d4, d3, d2, d1 = depth_outputs
        # f4, f3, f2, f1 = flow_outputs

        fd, depth_gate, q_maps = self.qgp([d1, d2, d3, d4], [r1, r2, r3, r4])
        [fd1, fd2, fd3, fd4] = fd
        [q1, q2, q3, q4] = q_maps
        # print(fd1.shape)
        # print(fd2.shape)
        # print(fd3.shape)
        # print(fd4.shape)

        r0 = self.layer5(r1)
        fuse1 = self.CIA_R1(r1, r0, fd1, q1)
        fuse2 = self.CIA_R2(r2, fuse1, fd2, q2)
        fuse3 = self.CIA_D1(r3, fd3, fuse2, q3)
        fuse4 = self.CIA_D2(r4, fd4, fuse3, q4)

        all_fused = [fuse4, fuse3, fuse2, fuse1]   # 从高分辨率到低分辨率

        # ==============================================================
        # 粒球解码器预测掩码
        # ==============================================================
        masks1 = self.decoder_fusion(all_fused)    # 融合分支
        # masks2 = self.decoder_rgb(rgb_outputs)     # RGB分支


        # 上采样到原始输入尺寸（例如512x512）
        masks1 = F.interpolate(masks1, (512, 512), mode='bilinear', align_corners=False)

        return masks1, depth_gate